package util.resource;

public class ResourcePathFinder {
    public String getName(ImageResource type) {
        return switch (type) {
            case DUKE -> "./DUKE.jpg";
            case CAPITAN -> "./CAPITAN.jpg";
            case ASSASSIN -> "./ASSASSIN.jpg";
            case AMBASSADOR -> "./AMBASSADOR.jpg";
            case PRINCESS -> "./PRINCESS.jpg";
            case UNKNOWN -> "./UNKNOWN.jpg";
            case BACKGROUND -> "./BACKGROUND.jpg";
            case GUIDE -> "./GUIDE.jpg";
        };
    }
}
