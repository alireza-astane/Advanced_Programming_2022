package util.resource;

public enum ImageResource {
    ASSASSIN,
    DUKE,
    CAPITAN,
    AMBASSADOR,
    PRINCESS,
    UNKNOWN,
    BACKGROUND,
    GUIDE
}
