import Gui.GuiMain;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.stage.Stage;
import javafx.scene.Scene;
import logic.*;

import java.io.IOException;



public class Main extends Application {

    public static void main(String[] args) throws IOException {
        Game.getInstance().setTurnOwner(Game.getInstance().getPlayerA());
        //todo check endgame
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Main.fxml"));

        Parent root;
        root = loader.load();
        GuiMain guiMain = loader.getController();

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

}