package logic;

public enum PlayerType {
    HUMAN,
    COWERED_COMMUNIST,
    COUP_MAKER,
    PARANOID,
    CAUTIOUS_ASSASSIN;
}
