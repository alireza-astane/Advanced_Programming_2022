package logic;

import Gui.GuiMain;
import com.google.gson.*;
import logic.Players.*;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import static logic.CardType.*;
import static logic.CardType.PRINCESS;
import static logic.Players.HUMAN.guiMain;

public class Game{
    public Game(){
        go=true;
    }
    private boolean go;
    private Player winner;
    private Player turnOwner;
    private ArrayList<CardType> groundCards;
    private ArrayList<Player> players;
    private ArrayList<Player> activePlayers;
    private Player A;
    private Player B;
    private Player C;
    private Player D;
    private ArrayList<Data> events = new ArrayList<>();

    public boolean isGo() {
        if(this.activePlayers.size()==1){
            this.setGo(false);
        }
        return go;
    }

    public Player getWinner() {
        return winner;
    }

    public ArrayList<CardType> getGroundCards() {
        return groundCards;
    }

    public ArrayList<Player> getPlayers() {
        return players;
    }

    public ArrayList<Player> getActivePlayers() {
        return activePlayers;
    }

    public void setActivePlayers(ArrayList<Player> activePlayers) {
        this.activePlayers = activePlayers;
    }

    public Player getPlayerA() {
        return A;
    }

    public Player getPlayerB() {
        return B;
    }

    public Player getPlayerC() {
        return C;
    }

    public Player getPlayerD() {
        return D;
    }

    public ArrayList<Data> getEvents() {
        return events;
    }

    public ArrayList<String> getListOfActions() {
        return listOfActions;
    }

    public void setPlayerA(Player A) {
        this.A = A;
    }

    public void setPlayerB(Player B) {
        this.B = B;
    }

    public void setPlayerC(Player C) {
        this.C = C;
    }

    public void setPlayerD(Player D) {
        this.D =D;
    }

    public void setPlayers(ArrayList<Player> players) {
        this.players = players;
    }

    public void setGo(boolean go) {
        this.go = go;
    }

    public Player getTurnOwner() {
        return turnOwner;
    }

    public void setGroundCards(ArrayList<CardType> groundCards) {
        this.groundCards = groundCards;
    }

    public void setTurnOwner(Player turnOwner) {
        this.turnOwner = turnOwner;
    }

    private static final Game instance = load();

    public void setWinner(Player winner) {
        this.winner = winner;
    }

    public void AddEvents(String event) {
        this.events.add(new Data(event));
    }

    public static Game getInstance() {
        return instance;
    }

    public static Game load() {
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();
        BufferedReader bufferedReader = null;
        String fileName =System.getProperty("user.dir")+"//src//main//config.json";
        try {
            bufferedReader = new BufferedReader(
                    new FileReader(fileName));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        assert bufferedReader != null;
        Configuration configuration=  gson.fromJson(bufferedReader, Configuration.class);

        Game game = new Game();
        ArrayList<CardType> list = new ArrayList<>();
        for(Object o:configuration.getGroundCards()){
            list.add((CardType)o);
        }
        game.setGroundCards(list);

        ArrayList<Player> players= new ArrayList<>();

        PlayerType AType = configuration.getPlayerAType();
        ArrayList<Card> ACards =  configuration.getPlayerACards();

        if(AType.equals(PlayerType.HUMAN)){
            HUMAN playerA = new HUMAN(); playerA.setName("A");playerA.setPlayerActiveCards(ACards);game.setPlayerA(playerA);players.add(playerA);}
        else {
            if (AType.equals(PlayerType.CAUTIOUS_ASSASSIN)) {
                CAUTIOUS_ASSASSIN playerA = new CAUTIOUS_ASSASSIN();
                playerA.setName("A");
                playerA.setPlayerActiveCards(ACards);
                game.setPlayerA(playerA);
                players.add(playerA);
            } else {
                if (AType.equals(PlayerType.COUP_MAKER)) {
                    COUP_MAKER playerA = new COUP_MAKER();
                    playerA.setName("A");
                    playerA.setPlayerActiveCards(ACards);
                    game.setPlayerA(playerA);
                    players.add(playerA);
                } else {
                    if (AType.equals(PlayerType.PARANOID)) {
                        PARANOID playerA = new PARANOID();
                        playerA.setName("A");
                        playerA.setPlayerActiveCards(ACards);
                        game.setPlayerA(playerA);
                        players.add(playerA);
                    } else {
                        COWARD_COMMUNIST playerA = new COWARD_COMMUNIST();
                        playerA.setName("A");
                        playerA.setPlayerActiveCards(ACards);
                        game.setPlayerA(playerA);
                        players.add(playerA);
                    }
                }
            }
        }

        PlayerType BType = configuration.playerBType;
        ArrayList<Card> BCards = configuration.getPlayerBCards();


        if(BType.equals(PlayerType.HUMAN)){
            HUMAN playerB = new HUMAN(); playerB.setName("B");playerB.setPlayerActiveCards(BCards);game.setPlayerB(playerB);players.add(playerB);
        }
        else {
            if (BType.equals(PlayerType.CAUTIOUS_ASSASSIN)) {
                CAUTIOUS_ASSASSIN playerB = new CAUTIOUS_ASSASSIN();
                playerB.setName("B");
                playerB.setPlayerActiveCards(BCards);
                game.setPlayerB(playerB);players.add(playerB);
            } else {
                if (BType.equals(PlayerType.COUP_MAKER)) {
                    COUP_MAKER playerB = new COUP_MAKER();
                    playerB.setName("B");
                    playerB.setPlayerActiveCards(BCards);
                    game.setPlayerB(playerB);
                    players.add(playerB);
                } else {
                    if (BType.equals(PlayerType.PARANOID)) {
                        PARANOID playerB = new PARANOID();
                        playerB.setName("B");
                        playerB.setPlayerActiveCards(BCards);
                        game.setPlayerB(playerB);players.add(playerB);
                    } else {
                        COWARD_COMMUNIST playerB = new COWARD_COMMUNIST();
                        playerB.setName("B");
                        playerB.setPlayerActiveCards(BCards);
                        game.setPlayerB(playerB);players.add(playerB);
                    }
                }
            }
        }

        PlayerType CType = configuration.getPlayerCType();
        ArrayList<Card> CCards = configuration.getPlayerCCards();



        if(CType.equals(PlayerType.HUMAN)){

            HUMAN playerC = new HUMAN(); playerC.setName("C");playerC.setPlayerActiveCards(CCards);game.setPlayerC(playerC);players.add(playerC);}
        else {
            if (CType.equals(PlayerType.CAUTIOUS_ASSASSIN)) {
                CAUTIOUS_ASSASSIN playerC = new CAUTIOUS_ASSASSIN();
                playerC.setName("C");
                playerC.setPlayerActiveCards(CCards);
                game.setPlayerC(playerC);players.add(playerC);
            } else {
                if (CType.equals(PlayerType.COUP_MAKER)) {
                    COUP_MAKER playerC = new COUP_MAKER();
                    playerC.setName("C");
                    playerC.setPlayerActiveCards(CCards);
                    game.setPlayerC(playerC);players.add(playerC);
                } else {
                    if (CType.equals(PlayerType.PARANOID)) {
                        PARANOID playerC = new PARANOID();
                        playerC.setName("C");
                        playerC.setPlayerActiveCards(CCards);
                        game.setPlayerC(playerC);players.add(playerC);
                    } else {
                        COWARD_COMMUNIST playerC = new COWARD_COMMUNIST();
                        playerC.setName("C");
                        playerC.setPlayerActiveCards(CCards);
                        game.setPlayerC(playerC);players.add(playerC);
                    }
                }
            }
        }

        PlayerType DType = configuration.getPlayerDType();
        ArrayList<Card> DCards = configuration.getPlayerDCards();

        if(DType.equals(PlayerType.HUMAN)){
            HUMAN playerD = new HUMAN(); playerD.setName("D");playerD.setPlayerActiveCards(DCards);game.setPlayerD(playerD);players.add(playerD);}
        else {
            if (DType.equals(PlayerType.CAUTIOUS_ASSASSIN)) {
                CAUTIOUS_ASSASSIN playerD = new CAUTIOUS_ASSASSIN();
                playerD.setName("D");
                playerD.setPlayerActiveCards(DCards);
                game.setPlayerD(playerD);players.add(playerD);
            } else {
                if (DType.equals(PlayerType.COUP_MAKER)) {
                    COUP_MAKER playerD = new COUP_MAKER();
                    playerD.setName("D");
                    playerD.setPlayerActiveCards(DCards);game.setPlayerA(playerD);
                    game.setPlayerD(playerD);players.add(playerD);
                } else {
                    if (DType.equals(PlayerType.PARANOID)) {
                        PARANOID playerD = new PARANOID();
                        playerD.setName("D");
                        playerD.setPlayerActiveCards(DCards);game.setPlayerA(playerD);
                        game.setPlayerD(playerD);players.add(playerD);
                    } else {
                        COWARD_COMMUNIST playerD = new COWARD_COMMUNIST();
                        playerD.setName("D");
                        playerD.setPlayerActiveCards(DCards);game.setPlayerA(playerD);
                        game.setPlayerD(playerD);players.add(playerD);
                    }
                }
            }
        }






        game.setActivePlayers(players);
        game.setPlayers(players);




        return game;
    }

    public void turn() {
        setTurnOwner(nextPlayer(turnOwner));
    }

    public Player nextPlayer(Player currentPlayer){
        if(players.size()==players.indexOf(currentPlayer)+1){
            if(players.get(0).isActive()){
                return players.get(0);}
            else{
                return nextPlayer(players.get(0));
            }
        }
        else{
            if(players.get(players.indexOf(currentPlayer)+1).isActive()){
            return players.get(players.indexOf(currentPlayer)+1);}
            else{
                return nextPlayer(players.get(players.indexOf(currentPlayer)+1));
            }
        }

    }

    public void endgame() {
        setWinner(activePlayers.get(0));
        guiMain.setWinner(getWinner());

    }

    private final ArrayList<String> listOfActions = new ArrayList<>(Arrays.asList("Ambassador", "Assassinate","Coup", "Exchange", "ForeignAid", "Income","Steal","Tax")); //todo

    public ArrayList<String> availableActions(){  //string or actionType
        ArrayList<String> list = new ArrayList<>(listOfActions);
        if(getPlayerA().getPlayerCoins()>=10){
            return new ArrayList<>(List.of("Coup"));
        }
        else{
            if(getPlayerA().getPlayerCoins()<7){
                list.remove("Coup");
            }
            if(getPlayerA().getPlayerCoins()<3){
                list.remove("Assassinate");
            }
            return list;
        }

    }


    public static void config() throws IOException {

        String fileName =System.getProperty("user.dir")+"//src//main//config.json";
        FileWriter writer;
        writer = new FileWriter(fileName);
        Configuration configuration = new Configuration();
        GsonBuilder builder = new GsonBuilder();
        Gson gson = builder.create();


        ArrayList<Card> ListA = new ArrayList<>(Arrays.asList(new Card(DUKE),new Card(ASSASSIN)));
        ArrayList<Card> ListB = new ArrayList<>(Arrays.asList(new Card(CAPITAN),new Card(ASSASSIN)));
        ArrayList<Card> ListC = new ArrayList<>(Arrays.asList(new Card(AMBASSADOR),new Card(PRINCESS)));
        ArrayList<Card> ListD = new ArrayList<>(Arrays.asList(new Card(DUKE),new Card(CAPITAN)));
        ArrayList<CardType> ListGroundCards = new ArrayList<>(Arrays.asList(DUKE,ASSASSIN,CAPITAN,AMBASSADOR,AMBASSADOR,PRINCESS,PRINCESS));

        configuration.setPlayerAType(PlayerType.HUMAN);
        configuration.setPlayerACards(ListA);

        configuration.setPlayerBType(PlayerType.COUP_MAKER);
        configuration.setPlayerBCards(ListB);

        configuration.setPlayerCType(PlayerType.PARANOID);
        configuration.setPlayerCCards(ListC);

        configuration.setPlayerDType(PlayerType.CAUTIOUS_ASSASSIN);
        configuration.setPlayerDCards(ListD);


        configuration.setGroundCards(ListGroundCards);


        writer.write(gson.toJson(configuration));
        writer.close();
    }

    public static void step(GuiMain guiMain) {
        if(getInstance().isGo()){
            Action action = (getInstance().getTurnOwner()).act();
            guiMain.update();
            if(action.isChallengeable()){
                action.search_for_challenge();
                guiMain.update();
            }
            if(action.isReactable()&&action.isGo()){
                action.search_for_reaction();
                guiMain.update();
            }



            if(action.isGo()){
                action.perform();
                guiMain.update();}
            if(getInstance().isGo()){
                getInstance().turn();
                guiMain.update();}

        }
        else{getInstance().endgame();guiMain.update();}
    }



}


