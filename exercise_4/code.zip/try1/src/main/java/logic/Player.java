package logic;

import java.util.ArrayList;

public abstract class Player {
    public Player(){
        active=true;
        playerCoins=2;
    }

    private String name;
    private PlayerType playerType;
    private ArrayList<Card> playerCards = new ArrayList<>();
    private ArrayList<Card> playerActiveCards = new ArrayList<>();
    private ArrayList<Card> playerSpoiledCards = new ArrayList<>();
    private int playerCoins;
    private boolean active;

    public boolean isActive() {
        return active;
    }

    public int getPlayerCoins() {
        return playerCoins;
    }

    public ArrayList<Card> getPlayerActiveCards() {
        return playerActiveCards;
    }

    public ArrayList<Card> getPlayerSpoiledCards() {
        return playerSpoiledCards;
    }

    public String getName() {
        return name;
    }

    public void setPlayerCoins(int playerCoins) {
        this.playerCoins = playerCoins;
    }

    public void setPlayerCards(ArrayList<Card> playerCards) {
        this.playerCards = playerCards;
    }


    public void setPlayerActiveCards(ArrayList<Card> playerActiveCards) {
        this.playerActiveCards = playerActiveCards;
        ArrayList<Card> list = new ArrayList<>();
        list.addAll(playerActiveCards);
        list.addAll(this.playerSpoiledCards);
        this.setPlayerCards(list);
    }

    public void setPlayerSpoiledCards(ArrayList<Card> playerSpoiledCards) {
        this.playerSpoiledCards = playerSpoiledCards;
    }

    public void setName(String name) {
        this.name = name;
    }


    public void setPlayerType(PlayerType playerType) {
        this.playerType = playerType;
    }

    public void setActive(boolean active) {
        this.active = active;
    }

    public ArrayList<Card> getPlayerCards() {
        return playerCards;
    }

    public PlayerType getPlayerType() {
        return playerType;
    }


    public abstract Action act();

    public abstract Action react_to_assassination(Action action);

    public abstract Action react_to_ForeignAid(Action action);

    public abstract Action react_to_Stealing(Action action);


    public boolean has_the_cardType(CardType type){
        for(Card card:this.getPlayerActiveCards()){
            if(card.getType().equals(type)){return true;}
        }
        return false;
    }


    public abstract boolean challenge(Action action);

    public abstract void choose_a_card_to_kill();

    public abstract ArrayList<Card> choose_for_exchange();



    public abstract Card choose_for_General_exchange();



    public abstract Player choose_to_attack();


}
