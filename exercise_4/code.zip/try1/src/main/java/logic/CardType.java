package logic;

public enum CardType{
    DUKE,
    ASSASSIN,
    CAPITAN,
    AMBASSADOR,
    PRINCESS
}
