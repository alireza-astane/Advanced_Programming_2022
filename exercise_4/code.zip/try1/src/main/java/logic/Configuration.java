package logic;

import java.util.ArrayList;

public class Configuration {
    protected PlayerType playerAType;
    protected PlayerType playerBType;
    protected PlayerType playerCType;
    protected PlayerType playerDType;
    protected ArrayList<Card> playerACards;
    protected ArrayList<Card> playerBCards;
    protected ArrayList<Card> playerCCards;
    protected ArrayList<Card> playerDCards;
    protected ArrayList<CardType> groundCards;

    public ArrayList<CardType> getGroundCards() {
        return groundCards;
    }

    public ArrayList<Card> getPlayerACards() {
        return playerACards;
    }

    public ArrayList<Card> getPlayerBCards() {
        return playerBCards;
    }

    public ArrayList<Card> getPlayerCCards() {
        return playerCCards;
    }

    public ArrayList<Card> getPlayerDCards() {
        return playerDCards;
    }

    public PlayerType getPlayerAType() {
        return playerAType;
    }

    public PlayerType getPlayerBType() {
        return playerBType;
    }

    public PlayerType getPlayerCType() {
        return playerCType;
    }

    public PlayerType getPlayerDType() {
        return playerDType;
    }

    public void setGroundCards(ArrayList<CardType> groundCards) {
        this.groundCards = groundCards;
    }

    public void setPlayerACards(ArrayList<Card> playerACards) {
        this.playerACards = playerACards;
    }

    public void setPlayerAType(PlayerType playerAType) {
        this.playerAType = playerAType;
    }

    public void setPlayerBCards(ArrayList<Card> playerBCards) {
        this.playerBCards = playerBCards;
    }

    public void setPlayerBType(PlayerType playerBType) {
        this.playerBType = playerBType;
    }

    public void setPlayerCCards(ArrayList<Card> playerCCards) {
        this.playerCCards = playerCCards;
    }

    public void setPlayerCType(PlayerType playerCType) {
        this.playerCType = playerCType;
    }

    public void setPlayerDCards(ArrayList<Card> playerDCards) {
        this.playerDCards = playerDCards;
    }

    public void setPlayerDType(PlayerType playerDType) {
        this.playerDType = playerDType;
    }
}
