package logic;

import java.util.ArrayList;
import java.util.Random;

public abstract class Action {
    public Action(){
        this.go=true;
    }


    private Player actor;
    private Object target;
    private boolean go;
    private boolean challengeable;
    private boolean reactable;
    private CardType requiredCard;

    public Player getActor() {
        return actor;
    }

    public CardType getRequiredCard() {
        return requiredCard;
    }

    public Object getTarget() {
        return target;
    }

    public boolean isChallengeable() {
        return challengeable;
    }

    public boolean isGo() {
        return go;
    }

    public boolean isReactable() {
        return reactable;
    }

    public void setChallengeable(boolean challengeable) {
        this.challengeable = challengeable;
    }

    public void challenge(Player challenger) {
        Game.getInstance().AddEvents(challenger.getName()+"->"+this.getActor().getName()+": "+"Challenge");
        if(this.getActor().has_the_cardType(this.getRequiredCard())){
            ArrayList<Card> list1 =new ArrayList<>(this.getActor().getPlayerActiveCards()) ;

            for(Card card :list1){
                if(card.getType().equals(this.requiredCard)){list1.remove(card);break;}
            }

            ArrayList<CardType> list2 = Game.getInstance().getGroundCards();
            list2.add(this.requiredCard);

            Random rand = new Random();
            CardType randomCard = list2.get(rand.nextInt(list2.size()));
            list2.remove(randomCard);
            list1.add(new Card(randomCard));

            Game.getInstance().setGroundCards(list2);
            this.getActor().setPlayerActiveCards(list1);

            challenger.choose_a_card_to_kill();
        }
        else{
            this.getActor().choose_a_card_to_kill();
            this.setGo(false);
        }
    }

    public abstract void perform();


    public void setRequiredCard(CardType requiredCard) {
        this.requiredCard = requiredCard;
    }

    public void setGo(boolean go) {
        this.go = go;
    }

    public void setReactable(boolean reactable) {
        this.reactable = reactable;
    }

    public void setActor(Player actor) {
        this.actor = actor;
    }

    public void setTarget(Object target) {
        this.target = target;
    }

    public abstract void search_for_challenge();

    public abstract void search_for_reaction();

}
