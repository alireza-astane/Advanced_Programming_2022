package logic.Players;

import logic.*;
import logic.Actions.*;

import java.util.ArrayList;
import java.util.Random;

public class COUP_MAKER extends Player {


    @Override
    public Action act() {
        if(this.getPlayerCoins()>=7){
            return new Coup(this,this.choose_to_attack());
        }
        else{
            return new Tax(this);
        }
    }

    @Override
    public Action react_to_assassination(Action action) {
        if(this.has_the_cardType(CardType.PRINCESS)){return new Block_Assassination(this,action);}
        else{
            double num = Math.random();
            if(num<0.9){
                return null;
            }
            else{return new Block_Assassination(this,action);
            }}
    }

    @Override
    public Action react_to_ForeignAid(Action action) {
        if(this.has_the_cardType(CardType.DUKE)){return new Block_ForeignAid(this,action);}


        else{
            double num = Math.random();
            if(num<0.9){
                return null;
            }
            else{return new Block_ForeignAid(this,action);
            }}
    }

    @Override
    public Action react_to_Stealing(Action action) {
        if (this.has_the_cardType(CardType.CAPITAN)) {
            return new Block_Stealing_By_Capitan(this, action);
        } else {
            if (this.has_the_cardType(CardType.AMBASSADOR)) {
                return new Block_Stealing_By_Ambassador(this, action);
            } else {
                double num = Math.random();
                if (num < 0.9) {
                    return null;
                } else {
                    if (num < 0.95) {
                        return new Block_Stealing_By_Capitan(this, action);
                    } else {
                        return new Block_Stealing_By_Ambassador(this, action);
                    }
                }

            }
        }
    }

    @Override
    public boolean challenge(Action action) {
        double num = Math.random();
        return (num >0.9);
    }

    @Override
    public void choose_a_card_to_kill() {
        Random rand = new Random();
        Card card = this.getPlayerActiveCards().get(rand.nextInt(this.getPlayerActiveCards().size()));
        card.setSpoiled(true);
        ArrayList<Card> list1 = this.getPlayerSpoiledCards();
        list1.add(card);
        ArrayList<Card> list2 = this.getPlayerActiveCards();
        list2.remove(card);
        setPlayerActiveCards(list2);
        setPlayerSpoiledCards(list1);
        Game.getInstance().AddEvents(this.getName() + "->" + "Kill: " + card.getType());
        if (this.getPlayerActiveCards().size() == 0) {
            this.setActive(false);
            ArrayList<Player> list3 = new ArrayList<>(Game.getInstance().getActivePlayers());
            list3.remove(this);
            Game.getInstance().setActivePlayers(list3);
            Game.getInstance().AddEvents(this.getName() + "->" + "Lost");

        }
    }

    @Override
    public ArrayList<Card> choose_for_exchange() {
        Random rand = new Random();
        ArrayList<Card> list1 = new ArrayList<>();
        for(int i=0;i<2;i++){
            Card card = this.getPlayerActiveCards().get(rand.nextInt(this.getPlayerActiveCards().size()));
            ArrayList<Card> list2 =new ArrayList<>(this.getPlayerCards()) ;
            list2.remove(card);
            this.setPlayerActiveCards(list2);
            list1.add(card);
        }
        return list1;
    }

    @Override
    public Card choose_for_General_exchange() {
        Random rand = new Random();
        return this.getPlayerActiveCards().get(rand.nextInt(this.getPlayerActiveCards().size()));
    }

    @Override
    public Player choose_to_attack() {
        ArrayList<Player> list1 = new ArrayList<>(Game.getInstance().getActivePlayers());
        list1.remove(this);
        Random rand = new Random();
        return list1.get(rand.nextInt(list1.size()));
    }
}
