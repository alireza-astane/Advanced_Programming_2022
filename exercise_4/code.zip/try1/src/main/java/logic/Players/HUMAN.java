package logic.Players;

import Gui.GuiMain;
import logic.Action;
import logic.Card;
import logic.Game;
import logic.Player;
import java.util.ArrayList;



public class HUMAN extends Player {
    public static GuiMain guiMain;

    @Override
    public Action act() {
        return guiMain.act_Dialog();
    }

    @Override
    public boolean challenge(Action action) {
        return guiMain.challenge_Dialog(action);

    }

    @Override
    public Action react_to_assassination(Action action) {
        return  guiMain.reaction_to_assassination_Dialog(action);



    }

    @Override
    public Action react_to_ForeignAid(Action action) {
        return guiMain.reaction_to_foreign_aid_Dialog(action);


    }

    @Override
    public Action react_to_Stealing(Action action) {
        return guiMain.reaction_to_steal_Dialog(action);


    }

    @Override
    public ArrayList<Card> choose_for_exchange() {
        return guiMain.ambassador_Dialog();
    }

    @Override
    public Card choose_for_General_exchange() {
        return guiMain.general_exchange_Dialog();


    }

    @Override
    public Player choose_to_attack() {
        return guiMain.choose_To_Attack_Dialog();
    }

    @Override
    public void choose_a_card_to_kill() {
        Card card = guiMain.choose_Card_To_Kill_Dialog();
        card.setSpoiled(true);
        ArrayList<Card> list1 = this.getPlayerSpoiledCards();
        list1.add(card);
        ArrayList<Card> list2 = this.getPlayerActiveCards();
        list2.remove(card);
        setPlayerActiveCards(list2);
        setPlayerSpoiledCards(list1);
        Game.getInstance().AddEvents(this.getName() + "->" + "Kill: " + card.getType());
        if (this.getPlayerActiveCards().size() == 0) {
            this.setActive(false);
            ArrayList<Player> list3 = new ArrayList<>(Game.getInstance().getActivePlayers());
            list3.remove(this);
            Game.getInstance().setActivePlayers(list3);
            Game.getInstance().AddEvents(this.getName() + "->" + "Lost");

        }
    }

}
