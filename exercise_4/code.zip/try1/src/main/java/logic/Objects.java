package logic;

public enum Objects {
    Deck("DECK"),
    Bank("BANK");

    private final String name;

    Objects(String name) {
        this.name=name;
    }

    public String getName() {
        return name;
    }
}
