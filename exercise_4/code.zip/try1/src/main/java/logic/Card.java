package logic;
public class Card {
    public Card(CardType type){
        this.spoiled=false;
        this.type=type;

    }
    private CardType type;
    private boolean spoiled;

    public CardType getType() {
        return type;
    }

    public boolean isSpoiled() {
        return spoiled;
    }


    public void setSpoiled(boolean spoiled) {
        this.spoiled = spoiled;
    }

    public void setType(CardType type) {
        this.type = type;
    }
}
