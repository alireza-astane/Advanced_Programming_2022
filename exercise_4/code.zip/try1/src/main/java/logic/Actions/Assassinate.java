package logic.Actions;

import logic.Action;
import logic.CardType;
import logic.Game;
import logic.Player;

public class Assassinate extends Action {
    public Assassinate(Player actor,Player target){
        super();
        this.setActor(actor);
        this.setChallengeable(true);
        this.setReactable(true);
        this.setGo(true);
        this.getActor().setPlayerCoins(this.getActor().getPlayerCoins()-3);
        this.setTarget(target);
        this.setRequiredCard(CardType.ASSASSIN);
        Game.getInstance().AddEvents(this.getActor().getName()+"->"+((Player)(this.getTarget())).getName()+": "+"Assassinate");
    }
    @Override
    public void perform() {
        if(((Player)this.getTarget()).isActive()){
        ((Player)this.getTarget()).choose_a_card_to_kill();}

    }

    @Override
    public void search_for_reaction() {
        Player reactor = (Player)this.getTarget();
        Action react = reactor.react_to_assassination(this);
        if (react != null){
            react.search_for_challenge();
            if(react.isGo()){
                react.perform();
            }
        }
    }

    @Override
    public void setGo(boolean go) {
        if(!go){this.getActor().setPlayerCoins(this.getActor().getPlayerCoins()+3);}
        super.setGo(go);
    }

    @Override
    public void search_for_challenge() {
        Player player =getActor();
        for (int i=1;i<Game.getInstance().getActivePlayers().size();i++){
            Player challenger = Game.getInstance().nextPlayer(player);
            player=challenger;
            if(challenger.challenge(this)){
                this.challenge(challenger);
                break;
            }}
    }
}
