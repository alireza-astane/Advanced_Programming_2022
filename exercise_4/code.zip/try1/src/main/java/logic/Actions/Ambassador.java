package logic.Actions;

import logic.*;

import java.util.ArrayList;
import java.util.Random;



public class Ambassador extends Action {
    public Ambassador(Player actor){
        super();
        this.setActor(actor);
        this.setChallengeable(true);
        this.setReactable(false);
        this.setGo(true);
        this.setTarget(Objects.Deck);
        this.setRequiredCard(CardType.AMBASSADOR);
        Game.getInstance().AddEvents(this.getActor().getName()+"->"+((Objects)this.getTarget()).getName()+": "+"Ambassador");
    }

    @Override
    public void perform() {
        ArrayList<CardType> list1 = Game.getInstance().getGroundCards();
        ArrayList<Card> list2 = new ArrayList<>();
        for(int i=0;i<2;i++){
            Random rand = new Random();
            CardType card = list1.get(rand.nextInt(list1.size()));
            list2.add(new Card(card));
            list1.remove(card);
        }

        ArrayList<Card> list3 = this.getActor().getPlayerActiveCards();
        list3.addAll(list2);
        this.getActor().setPlayerActiveCards(list3);

        ArrayList<Card> list4 = this.getActor().choose_for_exchange();

        list3.removeAll(list4);
        this.getActor().setPlayerActiveCards(list3);

        for(Card card:list4){
            list1.add(card.getType());
        }
        Game.getInstance().setGroundCards(list1);

    }

    @Override
    public void search_for_challenge() {
        Player player =getActor();;
        for (int i=1;i<Game.getInstance().getActivePlayers().size();i++){
            Player challenger = Game.getInstance().nextPlayer(player);
            player=challenger;
            if(challenger.challenge(this)){
                this.challenge(challenger);
                break;
            }}

    }

    @Override
    public void search_for_reaction() {

    }
}
