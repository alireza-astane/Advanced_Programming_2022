package logic.Actions;

import logic.*;

public class Tax extends Action {
    public Tax(Player actor){
        super();
        this.setActor(actor);
        this.setChallengeable(true);
        this.setReactable(false);
        this.setGo(true);
        this.setTarget(Objects.Bank);
        this.setRequiredCard(CardType.DUKE);
        Game.getInstance().AddEvents(this.getActor().getName()+"->"+((Objects)this.getTarget()).getName()+": "+"Tax");
    }
    @Override
    public void perform() {
        this.getActor().setPlayerCoins(this.getActor().getPlayerCoins()+3);
    }

    @Override
    public void search_for_challenge() {
        Player player =getActor();
        for (int i=1;i<Game.getInstance().getActivePlayers().size();i++){
            Player challenger = Game.getInstance().nextPlayer(player);
            player=challenger;
            if(challenger.challenge(this)){
                this.challenge(challenger);
                break;
            }}

    }

    @Override
    public void search_for_reaction() {
    }


}
