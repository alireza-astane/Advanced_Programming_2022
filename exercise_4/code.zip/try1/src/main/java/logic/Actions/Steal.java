package logic.Actions;

import logic.Action;
import logic.CardType;
import logic.Game;
import logic.Player;

public class Steal extends Action {
    public Steal(Player actor,Player target){
        super();
        this.setActor(actor);
        this.setChallengeable(true);
        this.setReactable(true);
        this.setGo(true);
        this.setTarget(target);
        this.setRequiredCard(CardType.CAPITAN);
        Game.getInstance().AddEvents(this.getActor().getName()+"->"+((Player)this.getTarget()).getName()+": "+"Steal");
    }
    @Override
    public void perform() {
        if(((Player)this.getTarget()).getPlayerCoins()>1){
            ((Player)this.getTarget()).setPlayerCoins(((Player)this.getTarget()).getPlayerCoins()-2);
            this.getActor().setPlayerCoins(this.getActor().getPlayerCoins()+2);

        }
        else{
            if(((Player)this.getTarget()).getPlayerCoins()==1){
                ((Player)this.getTarget()).setPlayerCoins(0);
                this.getActor().setPlayerCoins(this.getActor().getPlayerCoins()+1);
            }
        }
    }

    @Override
    public void search_for_challenge() {
        Player player =getActor();
        for (int i=1;i<Game.getInstance().getActivePlayers().size();i++){
            Player challenger = Game.getInstance().nextPlayer(player);
            player=challenger;
            if(challenger.challenge(this)){
                this.challenge(challenger);
                break;
            }}

    }

    @Override
    public void search_for_reaction() {
        Player reactor = (Player)this.getTarget();
        Action react = reactor.react_to_Stealing(this);
        if (react != null){
            react.search_for_challenge();
            if(react.isGo()){
                react.perform();
            }
        }
    }
}
