package logic.Actions;

import logic.Action;
import logic.Game;
import logic.Objects;
import logic.Player;

public class Income extends Action {
    public Income(Player actor){
        super();
        this.setActor(actor);
        this.setChallengeable(false);
        this.setReactable(false);
        this.setGo(true);
        this.setTarget(Objects.Bank);
        Game.getInstance().AddEvents(this.getActor().getName()+"->"+((Objects)this.getTarget()).getName()+": "+"Income");

    }
    @Override
    public void perform() {
        this.getActor().setPlayerCoins(this.getActor().getPlayerCoins()+1);
    }

    @Override
    public void search_for_challenge() {
    }

    @Override
    public void search_for_reaction() {

    }

}
