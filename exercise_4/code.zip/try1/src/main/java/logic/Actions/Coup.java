package logic.Actions;

import logic.Action;
import logic.Game;
import logic.Player;

public class Coup extends Action {

    public Coup(Player actor,Player target){
        super();
        this.setActor(actor);
        this.setChallengeable(false);
        this.setReactable(false);
        this.setGo(true);
        this.setTarget(target);
        Game.getInstance().AddEvents(this.getActor().getName()+"->"+((Player) this.getTarget()).getName()+": "+"Coup");
    }
    @Override
    public void perform() {
        this.getActor().setPlayerCoins(this.getActor().getPlayerCoins()-7);
        ((Player)this.getTarget()).choose_a_card_to_kill();

    }

    @Override
    public void search_for_challenge() {

    }

    @Override
    public void search_for_reaction() {

    }
}
