package logic.Actions;

import logic.Action;
import logic.CardType;
import logic.Game;
import logic.Player;

public class Block_Stealing_By_Capitan extends Action{
    private final Action action;
    public Block_Stealing_By_Capitan(Player actor, Action action) {
        this.setActor(actor);
        this.setChallengeable(true);
        this.setReactable(false);
        this.setGo(true);
        this.setRequiredCard(CardType.CAPITAN);
        this.action=action;
        Game.getInstance().AddEvents(this.getActor().getName()+"->"+this.action.getActor().getName()+": "+"Blocks Stealing by Capitan");
    }

    @Override
    public void perform() {
        action.setGo(false);


    }

    @Override
    public void search_for_challenge() {
        Player player =getActor();
        for (int i=1;i<Game.getInstance().getActivePlayers().size();i++){
            Player challenger = Game.getInstance().nextPlayer(player);
            player=challenger;
            if(challenger.challenge(this)){
                this.challenge(challenger);
                break;
            }}

    }

    @Override
    public void search_for_reaction() {

    }
}
