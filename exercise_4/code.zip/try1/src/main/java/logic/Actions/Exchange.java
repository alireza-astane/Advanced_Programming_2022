package logic.Actions;

import logic.*;

import java.util.ArrayList;
import java.util.Random;


public class Exchange extends Action {
    Card inputCard;
    public Exchange(Player actor,Card inputCard){
        super();
        this.setActor(actor);
        this.inputCard=inputCard;
        this.setChallengeable(false);
        this.setReactable(false);
        this.setGo(true);
        this.setTarget(Objects.Deck);
        Game.getInstance().AddEvents(this.getActor().getName()+"->"+((Objects)this.getTarget()).getName()+": "+"Exchange");
    }

    @Override
    public void perform() {
        this.getActor().setPlayerCoins(this.getActor().getPlayerCoins()-1);

        ArrayList<Card> list1 =new ArrayList<>(this.getActor().getPlayerActiveCards());
        list1.remove(inputCard);

        ArrayList<CardType> list2 =new ArrayList<>(Game.getInstance().getGroundCards()) ;
        list2.add(inputCard.getType());

        Random rand = new Random();
        CardType randomCard = list2.get(rand.nextInt(list2.size()));
        list2.remove(randomCard);
        list1.add(new Card(randomCard));

        Game.getInstance().setGroundCards(list2);
        this.getActor().setPlayerActiveCards(list1);

           }

    @Override
    public void search_for_challenge() {
    }

    @Override
    public void search_for_reaction() {

    }
}
