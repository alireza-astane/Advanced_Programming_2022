package logic.Actions;
import logic.Action;
import logic.Game;
import logic.Objects;
import logic.Player;

public class ForeignAid extends Action {
    public ForeignAid(Player actor){
        super();
        this.setActor(actor);
        this.setChallengeable(false);
        this.setReactable(true);
        this.setGo(true);
        this.setTarget(Objects.Bank);
        Game.getInstance().AddEvents(this.getActor().getName()+"->"+((Objects)this.getTarget()).getName()+": "+"Foreign Aid");

    }

    @Override
    public void perform() {
        this.getActor().setPlayerCoins(this.getActor().getPlayerCoins()+2);


    }

    @Override
    public void search_for_challenge() {

    }

    @Override
    public void search_for_reaction() {
        Player player = Game.getInstance().getTurnOwner();
        for (int i=1;i<Game.getInstance().getActivePlayers().size();i++){
            Player reactor = Game.getInstance().nextPlayer(player);
            player=reactor;
            Action react = reactor.react_to_ForeignAid(this);
            if(react!=null){
                react.search_for_challenge();
                if(react.isGo()){
                    react.perform();
                }
                break;
            }
        }
    }
}
