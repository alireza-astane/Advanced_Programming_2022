package Gui;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.stage.Popup;
import javafx.stage.Stage;
import logic.*;
import logic.Actions.*;
import logic.Objects;
import logic.Players.HUMAN;
import util.resource.ImageResource;
import util.resource.ResourcePathFinder;
import java.net.URL;
import java.util.*;


public class GuiMain implements Initializable{
    @FXML
    Button StepButton;
    @FXML
    Label ResultLabel = new Label();
    ResourcePathFinder finder = new ResourcePathFinder();

    @FXML
    ImageView BackGround= new ImageView();

    @FXML
    TableColumn<Object, Object> Column = new TableColumn<>("title");

    @FXML
    TableView<Object> GameEvenHistory = new TableView<>();

    @FXML
    Button GuideButton = new Button();

    @FXML
    ImageView PlayerACard1= new ImageView();

    @FXML
    ImageView PlayerACard2= new ImageView();

    @FXML
    Label PlayerACoins;

    @FXML
    ImageView PlayerBCard1 = new ImageView();

    @FXML
    ImageView PlayerBCard2= new ImageView();

    @FXML
    Label PlayerBCoins = new Label();

    @FXML
    ImageView PlayerCCard1= new ImageView();

    @FXML
    ImageView PlayerCCard2= new ImageView();

    @FXML
    Label PlayerCCoins= new Label();

    @FXML
    ImageView PlayerDCard1= new ImageView();

    @FXML
    ImageView PlayerDCard2= new ImageView();

    @FXML
    Label PlayerDCoins= new Label();

    @FXML
    Button ShowCardsButton = new Button();

    @FXML
    Label TurnOwnerLabel = new Label();

    Popup popup = new Popup();




    @FXML
    public void doShowCards(ActionEvent event) {
        setShowCards();
    }


    @Override
    public void initialize(URL location, ResourceBundle resources) {
        HUMAN.guiMain=this;
        update();

    }

    public void setShowCards(){
        ShowCardsButton.addEventFilter(MouseEvent.ANY, new EventHandler<MouseEvent>() {

            @Override
            public void handle(MouseEvent event) {
                if (event.getEventType().equals(MouseEvent.MOUSE_PRESSED)) {
                    PlayerACard1.setImage(new Image(finder.getName(ImageResource.valueOf(Game.getInstance().getPlayerA().getPlayerCards().get(0).getType().name()))));
                    PlayerACard2.setImage(new Image(finder.getName(ImageResource.valueOf(Game.getInstance().getPlayerA().getPlayerCards().get(1).getType().name()))));
                } else {
                    setPlayersCards();
                }
            }
        });
    }
    private void setPlayersCards() {
        if(!Game.getInstance().getPlayerB().getPlayerCards().get(0).isSpoiled()){
            PlayerBCard1.setImage(new Image(finder.getName(ImageResource.UNKNOWN)));
        }

        else{
            PlayerBCard1.setImage(new Image(finder.getName(ImageResource.valueOf(Game.getInstance().getPlayerB().getPlayerCards().get(0).getType().name()))));
        }

        if(!Game.getInstance().getPlayerB().getPlayerCards().get(1).isSpoiled()){
            PlayerBCard2.setImage(new Image(finder.getName(ImageResource.UNKNOWN)));
        }

        else{
            PlayerBCard2.setImage(new Image(finder.getName(ImageResource.valueOf(Game.getInstance().getPlayerB().getPlayerCards().get(1).getType().name()))));
        }




        if(!Game.getInstance().getPlayerC().getPlayerCards().get(0).isSpoiled()){
            PlayerCCard1.setImage(new Image(finder.getName(ImageResource.UNKNOWN)));
        }

        else{
            PlayerCCard1.setImage(new Image(finder.getName(ImageResource.valueOf(Game.getInstance().getPlayerC().getPlayerCards().get(0).getType().name()))));
        }


        if(!Game.getInstance().getPlayerC().getPlayerCards().get(1).isSpoiled()){
            PlayerCCard2.setImage(new Image(finder.getName(ImageResource.UNKNOWN)));
        }

        else{
            PlayerCCard2.setImage(new Image(finder.getName(ImageResource.valueOf(Game.getInstance().getPlayerC().getPlayerCards().get(1).getType().name()))));
        }




        if(!Game.getInstance().getPlayerD().getPlayerCards().get(0).isSpoiled()){
            PlayerDCard1.setImage(new Image(finder.getName(ImageResource.UNKNOWN)));
        }

        else{
            PlayerDCard1.setImage(new Image(finder.getName(ImageResource.valueOf(Game.getInstance().getPlayerD().getPlayerCards().get(0).getType().name()))));
        }
        PlayerDCard1.fitHeightProperty();

        if(!Game.getInstance().getPlayerD().getPlayerCards().get(1).isSpoiled()){
            PlayerDCard2.setImage(new Image(finder.getName(ImageResource.UNKNOWN)));
        }

        else{
            PlayerDCard2.setImage(new Image(finder.getName(ImageResource.valueOf(Game.getInstance().getPlayerD().getPlayerCards().get(1).getType().name()))));
        }


        if(!Game.getInstance().getPlayerA().getPlayerCards().get(0).isSpoiled()){
            PlayerACard1.setImage(new Image(finder.getName(ImageResource.UNKNOWN)));
        }

        else{
            PlayerACard1.setImage(new Image(finder.getName(ImageResource.valueOf(Game.getInstance().getPlayerA().getPlayerCards().get(0).getType().name()))));
        }


        if(!Game.getInstance().getPlayerA().getPlayerCards().get(1).isSpoiled()){
            PlayerACard2.setImage(new Image(finder.getName(ImageResource.UNKNOWN)));
        }

        else{
            PlayerACard2.setImage(new Image(finder.getName(ImageResource.valueOf(Game.getInstance().getPlayerA().getPlayerCards().get(1).getType().name()))));

        }

    }


        private void setPlayersCoins() {
        PlayerACoins.setText(String.valueOf(Game.getInstance().getPlayerA().getPlayerCoins()));
        PlayerACoins.resize(PlayerACoins.getWidth()*0.000001,PlayerACoins.getHeight());
        PlayerBCoins.setText(String.valueOf(Game.getInstance().getPlayerB().getPlayerCoins()));
            PlayerBCoins.resize(PlayerBCoins.getWidth()*0.000001,PlayerBCoins.getHeight());
        PlayerCCoins.setText(String.valueOf(Game.getInstance().getPlayerC().getPlayerCoins()));
            PlayerCCoins.resize(PlayerCCoins.getWidth()*0.000001,PlayerCCoins.getHeight());
        PlayerDCoins.setText(String.valueOf(Game.getInstance().getPlayerD().getPlayerCoins()));
            PlayerDCoins.resize(PlayerDCoins.getWidth()*0.000001,PlayerDCoins.getHeight());

    }

    public void doShowGuide(ActionEvent actionEvent) {
        Stage stage = ((Stage)(((Node)(actionEvent.getTarget())).getScene()).getWindow());
        ImageView image = new ImageView(new Image(finder.getName(ImageResource.GUIDE)));
        popup.getContent().add(image);
        if (!popup.isShowing()){
            popup.show(stage);
        }

        else
            popup.hide();
    }


    public void update() {
        setEvents();
        setShowCards();
        setPlayersCoins();
        setPlayersCards();
        try {
            setTurnOwner();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        BackGround.setImage((new Image(finder.getName(ImageResource.BACKGROUND))));
    }

    private void setTurnOwner() throws InterruptedException {
        TurnOwnerLabel.setText("Its "+Game.getInstance().getTurnOwner().getName()+"'s turn.");
    }

    public boolean challenge_Dialog(Action action){

        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Challenge Dialog");
        alert.setHeaderText(null);


        try{
            String targetName = ((Player)action.getTarget()).getName();
        alert.setContentText("Do you want to Challenge "+action.getActor().getName()+" doing "+action.getClass() +" on "+targetName);}
        catch (Exception e) {
            try {
                String targetName = ((Objects)action.getTarget()).getName();
                alert.setContentText("Do you want to Challenge "+action.getActor().getName()+" doing "+action.getClass() +" on "+targetName);


            } catch (Exception ex) {
                alert.setContentText("Do you want to Challenge "+action.getActor().getName()+" doing "+action.getClass());


            }

        }

        ButtonType buttonTypeOne = new ButtonType("Yes");
        ButtonType buttonTypeTwo = new ButtonType("No");

        alert.getButtonTypes().setAll(buttonTypeOne, buttonTypeTwo);

        Optional<ButtonType> result = alert.showAndWait();
        return result.get() == buttonTypeOne;
    }

    public Action reaction_to_foreign_aid_Dialog(Action action){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Reaction Dialog");
        alert.setHeaderText(null);
        alert.setContentText("Do you want to react to foreign aid done by"+action.getActor().getName()+"?");

        ButtonType buttonTypeOne = new ButtonType("Yes");
        ButtonType buttonTypeTwo = new ButtonType("No");

        alert.getButtonTypes().setAll(buttonTypeOne, buttonTypeTwo);

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == buttonTypeOne){
            return new Block_ForeignAid(Game.getInstance().getPlayerA(), action);
        } else {
            return null;
        }
    }

    public Action reaction_to_assassination_Dialog(Action action){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Reaction Dialog");
        alert.setHeaderText(null);
        alert.setContentText("Do you want to react to assassination done by"+action.getActor().getName()+"?");

        ButtonType buttonTypeOne = new ButtonType("Yes");
        ButtonType buttonTypeTwo = new ButtonType("No");

        alert.getButtonTypes().setAll(buttonTypeOne, buttonTypeTwo);

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == buttonTypeOne){
            return new Block_Assassination(Game.getInstance().getPlayerA(),action);
        } else {
            return null;
        }
    }

    public Action reaction_to_steal_Dialog(Action action){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Reaction Dialog");
        alert.setHeaderText(null);
        alert.setContentText("How  do you want to react to stealing done by"+action.getActor().getName()+"?");

        ButtonType buttonTypeOne = new ButtonType("By Ambassador");
        ButtonType buttonTypeTwo = new ButtonType("By Capitan");
        ButtonType buttonTypeThree = new ButtonType("None");

        alert.getButtonTypes().setAll(buttonTypeOne, buttonTypeTwo,buttonTypeThree);

        Optional<ButtonType> result = alert.showAndWait();
        if (result.get() == buttonTypeOne){
            return new Block_Stealing_By_Ambassador(Game.getInstance().getPlayerA(), action);
        } else {
            if(result.get() == buttonTypeTwo){
                return new Block_Stealing_By_Capitan(Game.getInstance().getPlayerA(),action);
            }
            else{
            return null;}
        }
    }


    public Card choose_Card_To_Kill_Dialog(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Kill Dialog");
        alert.setHeaderText(null);
        alert.setContentText("Which card are you going to spoil?");

        HashMap<String,Card> hashMap = new HashMap<>();
        ArrayList<ButtonType> list = new ArrayList<>();
        for(Card card:Game.getInstance().getPlayerA().getPlayerActiveCards()){
            hashMap.put(card.getType().name(),card);
            ButtonType buttonType = new ButtonType(card.getType().name());
            list.add(buttonType);
        }

        alert.getButtonTypes().setAll(list);

        Optional<ButtonType> result = alert.showAndWait();

return hashMap.get(result.get().getText());

    }

    public Player choose_To_Attack_Dialog(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Choose to Attack Dialog");
        alert.setHeaderText(null);
        alert.setContentText("Who do you want to attack?");

        ArrayList<ButtonType> list = new ArrayList<>();
        HashMap<String, Player> hashMap = new HashMap<>();
        ArrayList<Player> list2 = new ArrayList<>(Game.getInstance().getActivePlayers());
        list2.remove(Game.getInstance().getPlayerA());

        for(Player player:list2){
            hashMap.put(player.getName(),player);
            ButtonType buttonType = new ButtonType(player.getName());
            list.add(buttonType);
        }



        alert.getButtonTypes().setAll(list);
        alert.showAndWait();


        return hashMap.get(alert.getResult().getText());
    }

    public Card general_exchange_Dialog(){
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("Exchange Dialog");
        alert.setHeaderText(null);
        alert.setContentText("Choose card to exchange");

        HashMap<String,Card> hashMap = new HashMap<>();
        ArrayList<ButtonType> list =new ArrayList<>();

        for(Card card:Game.getInstance().getPlayerA().getPlayerActiveCards()){
            hashMap.put(card.getType().name(),card);
            ButtonType buttonType = new ButtonType(card.getType().name());
            list.add(buttonType);
        }

        alert.getButtonTypes().setAll(list);
        Optional<ButtonType> result = alert.showAndWait();

        Card card = hashMap.get(result.get().getText());

        return card;
    }


    public Action act_Dialog(){
        ChoiceDialog dialog = new ChoiceDialog("choose!",Game.getInstance().availableActions());
        dialog.setTitle("Action Dialog");
        dialog.setContentText("How do you wanna act?");

        dialog.showAndWait();
        return switch (dialog.getResult().toString()) {
            case "Ambassador" -> new Ambassador(Game.getInstance().getPlayerA());
            case "Assassinate" -> new Assassinate(Game.getInstance().getPlayerA(),choose_To_Attack_Dialog());
            case "Coup" -> new Coup(Game.getInstance().getPlayerA(),choose_To_Attack_Dialog());
            case "Exchange" -> new Exchange(Game.getInstance().getPlayerA(),general_exchange_Dialog());
            case "Tax" -> new Tax(Game.getInstance().getPlayerA());
            case "ForeignAid" -> new ForeignAid(Game.getInstance().getPlayerA());
            case "Income" -> new Income(Game.getInstance().getPlayerA());
            case "Steal" -> new Steal(Game.getInstance().getPlayerA(),choose_To_Attack_Dialog());
            default -> act_Dialog();
        };

    }



    public ArrayList<Card> ambassador_Dialog(){
        Alert alert1 = new Alert(Alert.AlertType.INFORMATION);
        alert1.setTitle("Ambassador Dialog");
        alert1.setHeaderText(null);
        alert1.setContentText("Choose first card to put back");

        HashMap<String,Card> hashMap1 = new HashMap<>();
        ArrayList<ButtonType> list1 =new ArrayList<>();

        for(Card card:Game.getInstance().getPlayerA().getPlayerActiveCards()){
            hashMap1.put(card.getType().name(),card);
            ButtonType buttonType = new ButtonType(card.getType().name());
            list1.add(buttonType);
        }

        alert1.getButtonTypes().setAll(list1);
        Optional<ButtonType> result = alert1.showAndWait();
        Card card1 = hashMap1.get(result.get().getText());



        Alert alert2 = new Alert(Alert.AlertType.INFORMATION);
        alert2.setTitle("Ambassador Dialog");
        alert2.setHeaderText(null);
        alert2.setContentText("choose second card to put back");

        HashMap<String,Card> hashMap2 = new HashMap<>();
        ArrayList<ButtonType> list2 =new ArrayList<>();

        ArrayList<Card> list =Game.getInstance().getPlayerA().getPlayerActiveCards();
        list.remove(card1);
        for(Card card:list){
            hashMap2.put(card.getType().name(),card);
            ButtonType buttonType = new ButtonType(card.getType().name());
            list2.add(buttonType);
        }

        alert2.getButtonTypes().setAll(list2);
        result = alert2.showAndWait();
        Card card2 = hashMap2.get(result.get().getText());
        return new ArrayList<>(Arrays.asList(card2,card1));

    }


    public void setEvents(){
        //Game.getInstance().getEvents();
        GameEvenHistory.getColumns().remove(Column);
        Column.setCellValueFactory(new PropertyValueFactory<>("text"));
        GameEvenHistory.getColumns().add(Column);
        GameEvenHistory.getItems().clear();
        for (Data data :Game.getInstance().getEvents()){
            GameEvenHistory.getItems().add(data);
        }

    }

    public void setWinner(Player winner) {
        ResultLabel.setText(winner.getName()+" won!");
    }

    public void doStep(ActionEvent actionEvent) {
        StepButton.setDisable(true);
        StepButton.setVisible(false);
        Game.step(this);
        StepButton.setDisable(false);
        StepButton.setVisible(true);
        //todo update?
    }
}
