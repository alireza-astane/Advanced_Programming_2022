package logic.enums;
public enum StudentState {
    ALLOWED_TO_REGISTER,
    EDUCATIONAL_LEAVE,
    GRADUATED,
    WITHDREW
}
