package logic.pageDataClasses;

import lombok.Getter;
import lombok.Setter;
import network.Response;

import java.util.ArrayList;

public class MohseniMessengerData extends Response {
}
