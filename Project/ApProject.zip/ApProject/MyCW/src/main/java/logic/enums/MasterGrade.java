package logic.enums;

public enum MasterGrade {
    POSTDOC,
    ASSOCIATE_PROFESSOR,
    ASSISTANT_PROFESSOR,
    PROFESSOR
}
