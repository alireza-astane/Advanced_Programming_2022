package logic.enums;

public enum ScoreType {
    NA,
    TEMPORARY,
    VERIFIED;
}
