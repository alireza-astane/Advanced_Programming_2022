package logic.enums;

public enum CourseType {
    UNDER_GRADUATION,
    MASTERY,
    PHD
}
