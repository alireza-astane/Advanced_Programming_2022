package logic.enums;

public enum UniRequestResultType {
    ACCEPTED,
    REJECTED,
    NOT_ANSWERED
}
