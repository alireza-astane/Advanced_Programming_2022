package logic.enums;

public enum EducationalContextType {
    File,
    TEXT, FILE;
}
