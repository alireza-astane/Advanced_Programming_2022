package logic.enums;

public enum DepartmentType {
    ELECTRICAL_ENGINEERING("Electrical Engineering");

    public final String name;

    DepartmentType(String s) {
        this.name=s;
    }
}
