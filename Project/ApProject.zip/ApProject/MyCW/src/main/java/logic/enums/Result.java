package logic.enums;

public enum Result {
    WRONG_USERNAME,
    WRONG_PASSWORD,
    WRONG_CAPTCHA,
    CHANGE_PASS_NEEDED,
}
