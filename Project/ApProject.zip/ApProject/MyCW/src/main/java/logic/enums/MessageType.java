package logic.enums;

public enum MessageType {
        File,
    TEXT, FILE;
}
