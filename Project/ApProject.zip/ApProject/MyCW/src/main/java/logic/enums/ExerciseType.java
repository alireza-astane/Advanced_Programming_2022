package logic.enums;

public enum ExerciseType {
    FILE,
    TEXT;
}
