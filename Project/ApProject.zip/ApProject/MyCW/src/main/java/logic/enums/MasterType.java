package logic.enums;

public enum MasterType {
    NORMAL,
    ASSISTANT,
    BOSS
}
