package logic.enums;

public enum UserType {
        MASTER,
        ASSISTANT,
    ADMIN, MOHSENI, STUDENT
}

