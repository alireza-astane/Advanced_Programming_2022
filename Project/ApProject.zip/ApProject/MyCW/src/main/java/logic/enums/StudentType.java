package logic.enums;

public enum StudentType {
        UNDERGRADUATE,
        MASTERY,
        PHD
}
