public enum Pages {
    MAIN_MENU
}
