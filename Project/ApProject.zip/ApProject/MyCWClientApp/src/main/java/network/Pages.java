package network;

public enum Pages {
    MAIN_MENU
}
