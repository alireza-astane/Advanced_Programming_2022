package logic.pageDataClasses;

import java.util.ArrayList;

public class CreateChatData {
    ArrayList<ArrayList<String>> userList;

    public ArrayList<ArrayList<String>> getUserList() {
        return userList;
    }

    public void setUserList(ArrayList<ArrayList<String>> userList) {
        this.userList = userList;
    }
//ArrayList: userFullName;

}
