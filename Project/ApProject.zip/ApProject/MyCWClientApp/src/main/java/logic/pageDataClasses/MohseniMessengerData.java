package logic.pageDataClasses;

import network.Response;

public class MohseniMessengerData extends Response {
}
