package Logic;
import java.util.ArrayList;

public class Choice {

    public ArrayList<Integer> pos;
    public Choice(ArrayList<Integer> pos) {
        this.pos = pos;
    }
}
