package util.resource;

public enum ImageResource {
    KING_W,
    KING_B,
    BISHOP_W,
    BISHOP_B,
    UP_BISHOP_W,
    UP_BISHOP_B,
    PAWN_W,
    PAWN_B,
    UP_PAWN_W,
    UP_PAWN_B,
    LANCE_W,
    LANCE_B,
    UP_LANCE_W,
    UP_LANCE_B,
    SILVERGENERAL_W,
    SILVERGENERAL_B,
    UP_SILVERGENERAL_W,
    UP_SILVERGENERAL_B,
    GOLDENGENERAL_W,
    GOLDENGENERAL_B,

    BOARD,
    WHAND,
    BHAND,
    BACKGROUND,
}
