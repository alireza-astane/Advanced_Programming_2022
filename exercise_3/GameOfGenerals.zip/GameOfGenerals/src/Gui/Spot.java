package Gui;
import javax.swing.*;

public class Spot extends JButton {
    public Spot() {
        setLayout(null);
        setOpaque(false);
        setFocusable(false);
        setBorderPainted(false);

        setContentAreaFilled(false);
    }
}
