import Gui.GameFrame;
import Logic.*;
public class GuiMain {
    static Game game = new Game();


    public static void main(String[] args) throws Exception {
        GameFrame frame = new GameFrame();
    }
}
