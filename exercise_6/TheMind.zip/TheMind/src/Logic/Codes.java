package Logic;

public enum Codes {
    S,   //Start
    P,   //Put card down
    Y,   //Yes
    N,   //No
    T,   //Throwing start
    Q,   //Quit
    E,   //Emoji
    //Numbers to select server,emojis,emoji targets,capacity
}
