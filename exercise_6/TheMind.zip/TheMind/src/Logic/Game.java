package Logic;

import java.util.ArrayList;

public class Game {
    protected int lastPlayedCard;
    protected ArrayList<Integer> playedCards;
    protected ArrayList<Player>  Players;
    protected GameData gameData;
    protected int lives;
    protected int throwingStars;
    protected int level;

    public void endGame(){}
    public void update(){}


}
