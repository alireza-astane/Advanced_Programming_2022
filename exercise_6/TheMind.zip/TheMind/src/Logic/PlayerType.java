package Logic;

public enum PlayerType {
    BOT,
    HUMAN
}
