package Logic;

public enum MessageType {
    INFO,
    REQUEST,
    CODE,
    INT_CHOICE,
    NAME,
    GAME_DATA,
    Emoji
}
